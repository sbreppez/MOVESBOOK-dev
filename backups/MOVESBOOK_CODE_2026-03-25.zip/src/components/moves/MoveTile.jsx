import React, { Fragment } from 'react';
import { C } from '../../constants/colors';
import { FONT_DISPLAY } from '../../constants/fonts';
import { Ic } from '../shared/Ic';
import { Highlight } from '../shared/Highlight';
import { masteryColor, CARD_BASE, CARD_BAR, CARD_BODY } from '../../constants/styles';
import { useSettings } from '../../hooks/useSettings';
import { CATS, CAT_COLORS } from '../../constants/categories';

export const MoveTile = ({ move, onClick, onEdit, onDelete, onDuplicate, onMove, allCats=CATS, catColors=CAT_COLORS, searchQuery="" }) => {
  const { settings } = useSettings();
  const col=masteryColor(move.mastery), catCol=catColors[move.category]||C.accent;
  const showMastery = settings.showMastery !== false;
  const compact = settings.compactCards;
  return (
    <div onClick={onClick} style={{ position:"relative", background:C.bg, border:`1px solid ${C.border}`, borderRadius:8,
      padding: compact ? "7px 8px 5px" : "10px 10px 8px", cursor:"pointer", borderLeft:`4px solid ${catCol}` }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom: showMastery ? 5 : 2 }}>
        <span style={{ fontWeight:700, fontSize: compact ? 13 : 15, color:C.text, lineHeight:1.2, flex:1, paddingRight:4, fontFamily:FONT_DISPLAY,
          overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", minWidth:0 }}>
          <Highlight text={move.name} query={searchQuery}/>
        </span>
        <div style={{ display:"flex", alignItems:"center", gap:2, flexShrink:0 }}>
          {move.link&&settings.linkOnCard==="both"&&(
            <a href={move.link.startsWith("http")?move.link:"https://"+move.link} target="_blank" rel="noopener noreferrer"
              onClick={e=>e.stopPropagation()}
              style={{ display:"flex", alignItems:"center", justifyContent:"center",
                width:20, height:20, borderRadius:5, color:C.textMuted, padding:2, textDecoration:"none" }}>
              <Ic n="extLink" s={12} c={C.textMuted}/>
            </a>
          )}
          <button onClick={e=>{e.stopPropagation();onDelete();}}
            style={{ background:"none", border:"none", cursor:"pointer", padding:2, display:"flex" }}>
            <Ic n="x" s={12} c={C.textMuted}/>
          </button>
        </div>
      </div>
      {move.description&&<div style={{ fontSize:10, color:C.textSec, lineHeight:1.4, marginBottom:4,
        overflow:"hidden", textOverflow:"ellipsis", display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical" }}>
        {move.description}
      </div>}
      {showMastery&&<Fragment>
        <div style={{ height:3, borderRadius:2, background:C.border, marginBottom:4 }}>
          <div style={{ height:"100%", width:`${move.mastery}%`, borderRadius:2, background:`linear-gradient(90deg,${C.red},${col})` }}/>
        </div>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ fontSize: compact ? 11 : 13, color:col, fontWeight:700 }}>{move.mastery}%</span>

        </div>
      </Fragment>}

    </div>
  );
};
